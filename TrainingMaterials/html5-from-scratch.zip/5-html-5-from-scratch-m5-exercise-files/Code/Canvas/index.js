<!DOCTYPE html>

<html lang="en">
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="mystyles.css" />
        <script src="script.js"></script>
        <title>Demo HTML5</title>
    </head>
    <body>
        <section id="CanvasSection">
             <canvas id="canvas" width="500" height="300"></canvas>          
        </section>
    </body>
</html>
